#include"RegistrationPage.h"
#include "Database.cpp"
public ref class RegistrationData :public Database {

public:
	virtual void InsertDataT(int Id, String^ name, String^ surname, String^ username, String^ password) {
		cmd = gcnew MySqlCommand("insert into taecher value(" + Id + ", '" + name + "', '" + surname + "', '" + username + "', '" + password + "')", DBconnect);
		DBconnect->Open();
		rdr = cmd->ExecuteReader();
	}
	virtual void InsertDataS(int Id, String^ name, String^ surname, String^ username, String^ password) {
		cmd = gcnew MySqlCommand("insert into studenttable value(" + Id + ", '" + name + "', '" + surname + "', '" + username + "', '" + password + "')", DBconnect);
		DBconnect->Open();
		rdr = cmd->ExecuteReader();
	}
};