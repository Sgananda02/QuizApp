
using namespace System;
using namespace MySql::Data::MySqlClient;

public ref class Database {
public:
	String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=quizapp";
	MySqlConnection^ DBconnect = gcnew MySqlConnection(constr);
	MySqlCommand^ cmd;
	MySqlDataReader^ rdr= rdr = cmd->ExecuteReader();;
	virtual void InsertData(int i,String^ A,String^ B) {
  
	}
	virtual void GetData(int i) {
		
	}
};



public ref class InformalData:public Database {
public:
	virtual void InsertDataI(int quizid,String^ quiztitle,String^ role ) {
		int Q = quizid;
		String^ QuizT = quiztitle;
		String^ R = role;
		cmd = gcnew MySqlCommand("insert into quiz_table value(" + Q + ",'" + QuizT + "','" + R + "')", DBconnect);
		DBconnect->Open();
		rdr = cmd->ExecuteReader();
	}
	
	virtual void GetDataQ(int quizid) {
		cmd = gcnew MySqlCommand("select * from question_answer where username=" + quizid + "", DBconnect);
		DBconnect->Open();
		rdr = cmd->ExecuteReader();
	}
};