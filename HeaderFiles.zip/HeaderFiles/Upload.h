#pragma once
#include <msclr\marshal_cppstd.h>
#include<string>
namespace Project4 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;
	using namespace MySql::Data::MySqlClient;
	using namespace System::Diagnostics;
	using namespace Runtime::InteropServices;
	//using namespace std;

	/// <summary>
	/// Summary for MyForm1
	/// </summary>
	public ref class Upload : public System::Windows::Forms::Form
	{
	public:
		Upload(System::Windows::Forms::Form^ TeacherPage, System::Windows::Forms::Form^ InformalPage)
		{   
			otherform = TeacherPage;
			otherform2 = InformalPage;
		    int quizId;
			String^ quizTitle;
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}
		
	public:
		int quizID;
		String^ quizTitle;
	private: System::Windows::Forms::Form^ otherform;
	private: System::Windows::Forms::SaveFileDialog^ saveFileDialog1;
	private: System::Windows::Forms::Form^ otherform2;
	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Upload()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Panel^ panel1;
	private: System::Windows::Forms::Button^ button3;
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::TextBox^ openText;


	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Button^ button4;
	private: System::Windows::Forms::OpenFileDialog^ openFileDialog1;
	private: System::Windows::Forms::Label^ FilePath;
	private: System::Windows::Forms::Label^ label1;

	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->FilePath = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->openText = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->openFileDialog1 = (gcnew System::Windows::Forms::OpenFileDialog());
			this->saveFileDialog1 = (gcnew System::Windows::Forms::SaveFileDialog());
			this->panel1->SuspendLayout();
			this->SuspendLayout();
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::SystemColors::HotTrack;
			this->panel1->Controls->Add(this->FilePath);
			this->panel1->Controls->Add(this->label1);
			this->panel1->Controls->Add(this->button3);
			this->panel1->Controls->Add(this->button2);
			this->panel1->Controls->Add(this->openText);
			this->panel1->Location = System::Drawing::Point(48, 35);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(371, 297);
			this->panel1->TabIndex = 0;
			// 
			// FilePath
			// 
			this->FilePath->AutoSize = true;
			this->FilePath->Location = System::Drawing::Point(89, 216);
			this->FilePath->Name = L"FilePath";
			this->FilePath->Size = System::Drawing::Size(90, 26);
			this->FilePath->TabIndex = 20;
			this->FilePath->Text = L"No file is selected\r\n\r\n";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(3, 216);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(91, 13);
			this->label1->TabIndex = 19;
			this->label1->Text = L"FileOpen Path:";
			// 
			// button3
			// 
			this->button3->BackColor = System::Drawing::SystemColors::HotTrack;
			this->button3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button3->Location = System::Drawing::Point(269, 243);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(75, 30);
			this->button3->TabIndex = 18;
			this->button3->Text = L"Save";
			this->button3->UseVisualStyleBackColor = false;
			this->button3->Click += gcnew System::EventHandler(this, &Upload::button3_Click);
			// 
			// button2
			// 
			this->button2->BackColor = System::Drawing::SystemColors::HotTrack;
			this->button2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button2->Location = System::Drawing::Point(20, 243);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(75, 30);
			this->button2->TabIndex = 17;
			this->button2->Text = L"Upload";
			this->button2->UseVisualStyleBackColor = false;
			this->button2->Click += gcnew System::EventHandler(this, &Upload::button2_Click);
			// 
			// openText
			// 
			this->openText->Location = System::Drawing::Point(20, 20);
			this->openText->Multiline = true;
			this->openText->Name = L"openText";
			this->openText->Size = System::Drawing::Size(324, 181);
			this->openText->TabIndex = 0;
			this->openText->Text = L"No file is open";
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::SystemColors::HotTrack;
			this->button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button1->Location = System::Drawing::Point(183, 338);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 30);
			this->button1->TabIndex = 16;
			this->button1->Text = L"Back";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &Upload::button1_Click);
			// 
			// button4
			// 
			this->button4->BackColor = System::Drawing::SystemColors::GrayText;
			this->button4->Location = System::Drawing::Point(412, 6);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(36, 23);
			this->button4->TabIndex = 17;
			this->button4->Text = L"X";
			this->button4->UseVisualStyleBackColor = false;
			this->button4->Click += gcnew System::EventHandler(this, &Upload::button4_Click);
			// 
			// openFileDialog1
			// 
			this->openFileDialog1->FileName = L"openFileDialog1";
			// 
			// Upload
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::MenuHighlight;
			this->ClientSize = System::Drawing::Size(460, 380);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->panel1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::None;
			this->Name = L"Upload";
			this->Text = L"MyForm1";
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			this->ResumeLayout(false);

		}
#pragma endregion
	String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=quizapp";
	MySqlConnection^ DBconnect = gcnew MySqlConnection(constr);
	
	MySqlDataReader^ rdr; 
	private: System::Void button4_Click(System::Object^ sender, System::EventArgs^ e) {
		if (MessageBox::Show("Do you really want to Exit?", "QuizAPP", MessageBoxButtons::YesNo, MessageBoxIcon::Question) == System::Windows::Forms::DialogResult::Yes) {
			Application::Exit();
		}
		else {
			System::Windows::Forms::DialogResult::Cancel;
		}
	}
private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {
	Stream^ myStream;
	OpenFileDialog^ open = gcnew OpenFileDialog();

	if (open->ShowDialog() == System::Windows::Forms::DialogResult::OK)
	{
		if ((myStream = open->OpenFile()) != nullptr)
		{
			String^ strfile = open->InitialDirectory + open->FileName;
			FilePath->Text = strfile;
			String^ Readfile = File::ReadAllText(strfile);
			if (strfile = "Text.txt") {
				openText->Text = Readfile;
				myStream->Close();
			}
			
		}
	 }

}
private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
	this->Hide();
	otherform->Show();
}
private: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e) {
	Stream^ myStream;
	SaveFileDialog^ save = gcnew  SaveFileDialog();
	String^ fileText= openText->Text;
	std::string str = msclr::interop::marshal_as<std::string>(fileText);
	
	
	DBconnect->Open();
	
}
};
}
