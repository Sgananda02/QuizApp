#pragma once
#include<string.h>
#include<iostream>
#include <sstream>

namespace Project4 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;
	/// <summary>
	/// Summary for AttemptQuiz
	/// </summary>
	public ref class AttemptQuiz : public System::Windows::Forms::Form
	{
	public:
		
		AttemptQuiz(System::Windows::Forms::Form^ StudentPage, System::Windows::Forms::Form^ InformalPage)
		{
			otherform = StudentPage;
			otherform2 = InformalPage;
			
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}
		
		
	private: System::Windows::Forms::Form^ otherform;
	private: System::Windows::Forms::Form^ otherform2;
	public: 
		int QuestionNo, FinalMark=0,quizId;
		String^ quizTilte;
		String^ Username;
		String^ Role;
	private: System::Windows::Forms::Panel^ Panel2;
	public:

	public:
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Button^ button1;
		   String^ correctAnswer;
	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~AttemptQuiz()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	protected:
	private: System::Windows::Forms::Label^ QuestionLabel;
	private: System::Windows::Forms::Label^ QuestionText;

	private: System::Windows::Forms::RadioButton^ Answer1But;
	private: System::Windows::Forms::RadioButton^ Answer2But;
	private: System::Windows::Forms::RadioButton^ Answer3But;
	private: System::Windows::Forms::RadioButton^ Answer4But;
	private: System::Windows::Forms::Panel^ panel1;

	private: System::Windows::Forms::Button^ NextBut;
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::Button^ button3;
	private: System::Windows::Forms::Button^ BackBut;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->QuestionLabel = (gcnew System::Windows::Forms::Label());
			this->QuestionText = (gcnew System::Windows::Forms::Label());
			this->Answer1But = (gcnew System::Windows::Forms::RadioButton());
			this->Answer2But = (gcnew System::Windows::Forms::RadioButton());
			this->Answer3But = (gcnew System::Windows::Forms::RadioButton());
			this->Answer4But = (gcnew System::Windows::Forms::RadioButton());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->Panel2 = (gcnew System::Windows::Forms::Panel());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->NextBut = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->BackBut = (gcnew System::Windows::Forms::Button());
			this->panel1->SuspendLayout();
			this->Panel2->SuspendLayout();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(86, 17);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(81, 20);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Question";
			// 
			// QuestionLabel
			// 
			this->QuestionLabel->AutoSize = true;
			this->QuestionLabel->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->QuestionLabel->Location = System::Drawing::Point(173, 17);
			this->QuestionLabel->Name = L"QuestionLabel";
			this->QuestionLabel->Size = System::Drawing::Size(19, 20);
			this->QuestionLabel->TabIndex = 1;
			this->QuestionLabel->Text = L"1";
			// 
			// QuestionText
			// 
			this->QuestionText->AutoSize = true;
			this->QuestionText->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->QuestionText->Location = System::Drawing::Point(18, 49);
			this->QuestionText->Name = L"QuestionText";
			this->QuestionText->Size = System::Drawing::Size(149, 16);
			this->QuestionText->TabIndex = 2;
			this->QuestionText->Text = L"no questionis available!\t\n";
			// 
			// Answer1But
			// 
			this->Answer1But->AutoSize = true;
			this->Answer1But->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Answer1But->Location = System::Drawing::Point(70, 93);
			this->Answer1But->Name = L"Answer1But";
			this->Answer1But->Size = System::Drawing::Size(77, 20);
			this->Answer1But->TabIndex = 3;
			this->Answer1But->TabStop = true;
			this->Answer1But->Text = L"Answer1";
			this->Answer1But->UseVisualStyleBackColor = true;
			// 
			// Answer2But
			// 
			this->Answer2But->AutoSize = true;
			this->Answer2But->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Answer2But->Location = System::Drawing::Point(70, 119);
			this->Answer2But->Name = L"Answer2But";
			this->Answer2But->Size = System::Drawing::Size(77, 20);
			this->Answer2But->TabIndex = 4;
			this->Answer2But->TabStop = true;
			this->Answer2But->Text = L"Answer2";
			this->Answer2But->UseVisualStyleBackColor = true;
			// 
			// Answer3But
			// 
			this->Answer3But->AutoSize = true;
			this->Answer3But->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Answer3But->Location = System::Drawing::Point(70, 145);
			this->Answer3But->Name = L"Answer3But";
			this->Answer3But->Size = System::Drawing::Size(77, 20);
			this->Answer3But->TabIndex = 5;
			this->Answer3But->TabStop = true;
			this->Answer3But->Text = L"Answer3";
			this->Answer3But->UseVisualStyleBackColor = true;
			// 
			// Answer4But
			// 
			this->Answer4But->AutoSize = true;
			this->Answer4But->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Answer4But->Location = System::Drawing::Point(70, 171);
			this->Answer4But->Name = L"Answer4But";
			this->Answer4But->Size = System::Drawing::Size(77, 20);
			this->Answer4But->TabIndex = 6;
			this->Answer4But->TabStop = true;
			this->Answer4But->Text = L"Answer4";
			this->Answer4But->UseVisualStyleBackColor = true;
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::SystemColors::HotTrack;
			this->panel1->Controls->Add(this->Panel2);
			this->panel1->Controls->Add(this->NextBut);
			this->panel1->Controls->Add(this->label1);
			this->panel1->Controls->Add(this->QuestionText);
			this->panel1->Controls->Add(this->Answer4But);
			this->panel1->Controls->Add(this->QuestionLabel);
			this->panel1->Controls->Add(this->Answer3But);
			this->panel1->Controls->Add(this->Answer2But);
			this->panel1->Controls->Add(this->Answer1But);
			this->panel1->Location = System::Drawing::Point(52, 53);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(341, 262);
			this->panel1->TabIndex = 7;
			// 
			// Panel2
			// 
			this->Panel2->Controls->Add(this->button1);
			this->Panel2->Controls->Add(this->label2);
			this->Panel2->Location = System::Drawing::Point(3, 3);
			this->Panel2->Name = L"Panel2";
			this->Panel2->Size = System::Drawing::Size(338, 259);
			this->Panel2->TabIndex = 8;
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::SystemColors::HotTrack;
			this->button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button1->Location = System::Drawing::Point(136, 168);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(53, 30);
			this->button1->TabIndex = 8;
			this->button1->Text = L"Start";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &AttemptQuiz::button1_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(63, 93);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(194, 20);
			this->label2->TabIndex = 0;
			this->label2->Text = L"Press Start Button to start";
			// 
			// NextBut
			// 
			this->NextBut->BackColor = System::Drawing::SystemColors::HotTrack;
			this->NextBut->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->NextBut->Location = System::Drawing::Point(270, 218);
			this->NextBut->Name = L"NextBut";
			this->NextBut->Size = System::Drawing::Size(53, 30);
			this->NextBut->TabIndex = 7;
			this->NextBut->Text = L"Next";
			this->NextBut->UseVisualStyleBackColor = false;
			this->NextBut->Click += gcnew System::EventHandler(this, &AttemptQuiz::NextBut_Click);
			// 
			// button2
			// 
			this->button2->BackColor = System::Drawing::SystemColors::GrayText;
			this->button2->Location = System::Drawing::Point(396, 12);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(36, 23);
			this->button2->TabIndex = 8;
			this->button2->Text = L"X";
			this->button2->UseVisualStyleBackColor = false;
			this->button2->Click += gcnew System::EventHandler(this, &AttemptQuiz::button2_Click);
			// 
			// button3
			// 
			this->button3->BackColor = System::Drawing::SystemColors::HotTrack;
			this->button3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button3->Location = System::Drawing::Point(296, 338);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(121, 30);
			this->button3->TabIndex = 9;
			this->button3->Text = L"Finish Attempt";
			this->button3->UseVisualStyleBackColor = false;
			this->button3->Click += gcnew System::EventHandler(this, &AttemptQuiz::button3_Click);
			// 
			// BackBut
			// 
			this->BackBut->BackColor = System::Drawing::SystemColors::HotTrack;
			this->BackBut->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->BackBut->Location = System::Drawing::Point(52, 338);
			this->BackBut->Name = L"BackBut";
			this->BackBut->Size = System::Drawing::Size(75, 30);
			this->BackBut->TabIndex = 10;
			this->BackBut->Text = L"Back";
			this->BackBut->UseVisualStyleBackColor = false;
			this->BackBut->Click += gcnew System::EventHandler(this, &AttemptQuiz::BackBut_Click);
			// 
			// AttemptQuiz
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::MenuHighlight;
			this->ClientSize = System::Drawing::Size(460, 380);
			this->Controls->Add(this->BackBut);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->panel1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::None;
			this->Name = L"AttemptQuiz";
			this->Text = L"AttemptQuiz";
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			this->Panel2->ResumeLayout(false);
			this->Panel2->PerformLayout();
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {
		if (MessageBox::Show("Do you really want to Exit?", "QuizAPP", MessageBoxButtons::YesNo, MessageBoxIcon::Question) == System::Windows::Forms::DialogResult::Yes) {
			Application::Exit();
		}
		else {
			System::Windows::Forms::DialogResult::Cancel;
		}
	}
private: System::Void NextBut_Click(System::Object^ sender, System::EventArgs^ e) {
	for (int i = 1; i <= QuestionNo; i++) {
	String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=quizapp";
	MySqlConnection^ DBconnect1 = gcnew MySqlConnection(constr);
	MySqlCommand^ cmd1 = gcnew MySqlCommand("select * from question_answer where quizId=" + quizId + "", DBconnect1);
	DBconnect1->Open();
	MySqlDataReader^ reader1 = cmd1->ExecuteReader();
	while (reader1->Read()) {
		String^ Q = reader1->GetString(2);
		String^ Ans1 = reader1->GetString(3);
		String^ Ans2 = reader1->GetString(4);
		String^ Ans3 = reader1->GetString(5);
		String^ Ans4 = reader1->GetString(6);
		correctAnswer = reader1->GetString(7);
		QuestionNo = Int32::Parse(reader1->GetString(8));
		if (Ans1 = correctAnswer) {
			FinalMark += 1;
		}
		else if (Ans2 = correctAnswer) {
			FinalMark += 1;
		}
		else if (Ans3 = correctAnswer) {
			FinalMark += 1;
		}
		else  {
			FinalMark += 1;
		}
	    this->QuestionLabel->Text = System::Convert::ToString(i);
	    this->QuestionText->Text = Q;
		this->Answer1But->Text = Ans1;
		this->Answer2But->Text = Ans2;
		this->Answer3But->Text = Ans3;
		this->Answer4But->Text = Ans4;
		quizId = quizId + 1;
		}
	
	}
	
}
private: System::Void BackBut_Click(System::Object^ sender, System::EventArgs^ e) {
	this->Hide();
	otherform->Show();
}
private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
	Panel2->Hide();
	String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=quizapp";
	MySqlConnection^ DBconnect1 = gcnew MySqlConnection(constr);
	MySqlCommand^ cmd1 = gcnew MySqlCommand("select * from question_answer where quizId=" + quizId + "", DBconnect1);
	DBconnect1->Open();
	MySqlDataReader^ reader1 = cmd1->ExecuteReader();
	while (reader1->Read()) {
		String^ Q = reader1->GetString(2);
		String^ Ans1 = reader1->GetString(3);
		String^ Ans2 = reader1->GetString(4);
		String^ Ans3 = reader1->GetString(5);
		String^ Ans4 = reader1->GetString(6);
		correctAnswer = reader1->GetString(7);
		QuestionNo = Int32::Parse(reader1->GetString(8));

		this->QuestionText->Text = Q;
		this->Answer1But->Text = Ans1;
		this->Answer2But->Text = Ans2;
		this->Answer3But->Text = Ans3;
		this->Answer4But->Text = Ans4;
		
	
	
	}

}
private: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e) {
	
	String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=quizapp";
	MySqlConnection^ DBconnect1 = gcnew MySqlConnection(constr);
	if (Role="Teacher") {
		MySqlCommand^ cmd1 = gcnew MySqlCommand("insert into studentmarks value('" + Username + "'," + quizId + ",'" + quizTilte + "'," + FinalMark + ")", DBconnect1);
		DBconnect1->Open();
		MySqlDataReader^ reader1 = cmd1->ExecuteReader();
		MessageBox::Show("Your final Mark is:" + System::Convert::ToString(FinalMark));
	}
	else {
		MySqlCommand^ cmd1 = gcnew MySqlCommand("insert into user_table value('" + Username + "'," + FinalMark + ")", DBconnect1);
		DBconnect1->Open();
		MySqlDataReader^ reader1 = cmd1->ExecuteReader();
		MessageBox::Show("Your final Mark is:" + System::Convert::ToString(FinalMark));
	}
}
};
}
