#pragma once

#include "TeacherPage.h"
#include "StudentPage.h"
#include "HomePage.h"
#include "RegistrationPage.h"
namespace Project4 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for MyForm1
	/// </summary>
	public ref class FormalPage : public System::Windows::Forms::Form
	{
		
	public:
		FormalPage(System::Windows::Forms::Form ^ HomePage)
		{
			otherform = HomePage;
			InitializeComponent();
			
			
			//TODO: Add the constructor code here
			//
		}
	private: System::Windows::Forms::Form^ otherform;

		
	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~FormalPage()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Panel^ panel1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::LinkLabel^ linkLabel1;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::TextBox^ PasswordText;

	private: System::Windows::Forms::TextBox^ UserNameText;

	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::RadioButton^ StudentBut;

	private: System::Windows::Forms::RadioButton^ TeacherBut;

	private: System::Windows::Forms::Button^ BackBut;

	private: System::Windows::Forms::Button^ NextBut;
	private: System::Windows::Forms::Button^ button1;

	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->linkLabel1 = (gcnew System::Windows::Forms::LinkLabel());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->PasswordText = (gcnew System::Windows::Forms::TextBox());
			this->UserNameText = (gcnew System::Windows::Forms::TextBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->StudentBut = (gcnew System::Windows::Forms::RadioButton());
			this->TeacherBut = (gcnew System::Windows::Forms::RadioButton());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->BackBut = (gcnew System::Windows::Forms::Button());
			this->NextBut = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->panel1->SuspendLayout();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Elephant", 36, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(57, 9);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(334, 62);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Formal Quiz";
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::SystemColors::HotTrack;
			this->panel1->Controls->Add(this->linkLabel1);
			this->panel1->Controls->Add(this->label6);
			this->panel1->Controls->Add(this->PasswordText);
			this->panel1->Controls->Add(this->UserNameText);
			this->panel1->Controls->Add(this->label5);
			this->panel1->Controls->Add(this->label4);
			this->panel1->Controls->Add(this->label3);
			this->panel1->Controls->Add(this->StudentBut);
			this->panel1->Controls->Add(this->TeacherBut);
			this->panel1->Controls->Add(this->label2);
			this->panel1->Location = System::Drawing::Point(56, 74);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(362, 251);
			this->panel1->TabIndex = 1;
			// 
			// linkLabel1
			// 
			this->linkLabel1->AutoSize = true;
			this->linkLabel1->LinkColor = System::Drawing::Color::White;
			this->linkLabel1->Location = System::Drawing::Point(175, 231);
			this->linkLabel1->Name = L"linkLabel1";
			this->linkLabel1->Size = System::Drawing::Size(28, 13);
			this->linkLabel1->TabIndex = 12;
			this->linkLabel1->TabStop = true;
			this->linkLabel1->Text = L"here";
			this->linkLabel1->LinkClicked += gcnew System::Windows::Forms::LinkLabelLinkClickedEventHandler(this, &FormalPage::linkLabel1_LinkClicked);
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Italic, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label6->Location = System::Drawing::Point(14, 229);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(164, 15);
			this->label6->TabIndex = 11;
			this->label6->Text = L"if you are not registered click ";
			// 
			// PasswordText
			// 
			this->PasswordText->BackColor = System::Drawing::SystemColors::Menu;
			this->PasswordText->Location = System::Drawing::Point(109, 179);
			this->PasswordText->Name = L"PasswordText";
			this->PasswordText->PasswordChar = '*';
			this->PasswordText->Size = System::Drawing::Size(226, 20);
			this->PasswordText->TabIndex = 10;
			// 
			// UserNameText
			// 
			this->UserNameText->BackColor = System::Drawing::SystemColors::Menu;
			this->UserNameText->Location = System::Drawing::Point(109, 148);
			this->UserNameText->Name = L"UserNameText";
			this->UserNameText->Size = System::Drawing::Size(226, 20);
			this->UserNameText->TabIndex = 9;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(13, 177);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(100, 20);
			this->label5->TabIndex = 8;
			this->label5->Text = L"Passsword:";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(17, 146);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(96, 20);
			this->label4->TabIndex = 7;
			this->label4->Text = L"Username:";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(3, 108);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(64, 20);
			this->label3->TabIndex = 6;
			this->label3->Text = L"Sign in";
			// 
			// StudentBut
			// 
			this->StudentBut->AutoSize = true;
			this->StudentBut->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->StudentBut->Location = System::Drawing::Point(55, 66);
			this->StudentBut->Name = L"StudentBut";
			this->StudentBut->Size = System::Drawing::Size(84, 24);
			this->StudentBut->TabIndex = 5;
			this->StudentBut->TabStop = true;
			this->StudentBut->Text = L"Student";
			this->StudentBut->UseVisualStyleBackColor = true;
			// 
			// TeacherBut
			// 
			this->TeacherBut->AutoSize = true;
			this->TeacherBut->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->TeacherBut->Location = System::Drawing::Point(55, 36);
			this->TeacherBut->Name = L"TeacherBut";
			this->TeacherBut->Size = System::Drawing::Size(85, 24);
			this->TeacherBut->TabIndex = 4;
			this->TeacherBut->TabStop = true;
			this->TeacherBut->Text = L"Teacher";
			this->TeacherBut->UseVisualStyleBackColor = true;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(3, 13);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(93, 20);
			this->label2->TabIndex = 3;
			this->label2->Text = L"Sign in as:";
			// 
			// BackBut
			// 
			this->BackBut->BackColor = System::Drawing::SystemColors::HotTrack;
			this->BackBut->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->BackBut->Location = System::Drawing::Point(56, 338);
			this->BackBut->Name = L"BackBut";
			this->BackBut->Size = System::Drawing::Size(75, 30);
			this->BackBut->TabIndex = 3;
			this->BackBut->Text = L"Back";
			this->BackBut->UseVisualStyleBackColor = false;
			this->BackBut->Click += gcnew System::EventHandler(this, &FormalPage::BackBut_Click);
			// 
			// NextBut
			// 
			this->NextBut->BackColor = System::Drawing::SystemColors::HotTrack;
			this->NextBut->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->NextBut->Location = System::Drawing::Point(334, 338);
			this->NextBut->Name = L"NextBut";
			this->NextBut->Size = System::Drawing::Size(75, 30);
			this->NextBut->TabIndex = 4;
			this->NextBut->Text = L"Next";
			this->NextBut->UseVisualStyleBackColor = false;
			this->NextBut->Click += gcnew System::EventHandler(this, &FormalPage::NextBut_Click);
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::SystemColors::GrayText;
			this->button1->Location = System::Drawing::Point(412, 12);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(36, 23);
			this->button1->TabIndex = 5;
			this->button1->Text = L"X";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &FormalPage::button1_Click);
			// 
			// FormalPage
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::MenuHighlight;
			this->ClientSize = System::Drawing::Size(460, 380);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->NextBut);
			this->Controls->Add(this->BackBut);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->label1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::None;
			this->Name = L"FormalPage";
			this->Text = L"MyForm1";
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void NextBut_Click(System::Object^ sender, System::EventArgs^ e) {
		
		
			try {
				String^ username = UserNameText->Text;
				String^ password = PasswordText->Text;
				String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=quizapp";
				MySqlConnection^ DBconnect = gcnew MySqlConnection(constr);
				if (TeacherBut->Checked) {
					MySqlCommand^ cmd = gcnew MySqlCommand("select * from teacher where username='" + username + "'", DBconnect);
					DBconnect->Open();
					MySqlDataReader^ reader = cmd->ExecuteReader();
					while (reader->Read()) {
						String^ UserN = reader->GetString(3);
						String^ PassW = reader->GetString(4);

						if (username == UserN && password == PassW) {
							MessageBox::Show("Successfully logged in, Press Ok to continue");
							UserNameText->Text = " ";
							PasswordText->Text = " ";
							this->Hide();
							TeacherPage^ t = gcnew TeacherPage(this);
							t->Show();
						}
						else {
							MessageBox::Show("Invalid Password or Username ", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
						}
					}
				}
				else {
					MySqlCommand^ cmd = gcnew MySqlCommand("select * from studenttable where username='" + username + "'", DBconnect);
					DBconnect->Open();
					MySqlDataReader^ reader = cmd->ExecuteReader();
					while (reader->Read()) {
						String^ UserN = reader->GetString(3);
						String^ PassW = reader->GetString(4);

						if (username == UserN && password == PassW) {
							MessageBox::Show("Successfully logged in, Press Ok to continue");
							UserNameText->Text = " ";
							PasswordText->Text = " ";
							this->Hide();
							StudentPage^ stud = gcnew StudentPage(this);
							stud->username;
							stud->Show();
						}
						else {
							MessageBox::Show("Invalid Password or Username ", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
						}
					}




				}
			}
			catch (Exception^ ex) {
				MessageBox::Show(ex->Message);
			}
		}
		
	
private: System::Void BackBut_Click(System::Object^ sender, System::EventArgs^ e) {
	this->Hide();
	otherform->Show();
	
}
private: System::Void linkLabel1_LinkClicked(System::Object^ sender, System::Windows::Forms::LinkLabelLinkClickedEventArgs^ e) {
    this->Hide();
	RegistrationPage^ Reg = gcnew RegistrationPage(this);
	Reg->Show();
}
private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
	if (MessageBox::Show("Do you really want to Exit?", "QuizAPP", MessageBoxButtons::YesNo, MessageBoxIcon::Question) == System::Windows::Forms::DialogResult::Yes) {
		Application::Exit();
	}
	else {
		System::Windows::Forms::DialogResult::Cancel;
	}
}
};
}
