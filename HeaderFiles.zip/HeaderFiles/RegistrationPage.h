#pragma once
#include "Database.cpp"
#include "RegistrationData.cpp"
namespace Project4 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for MyForm3
	/// </summary>
	public ref class RegistrationPage : public System::Windows::Forms::Form
	{
	public:
		RegistrationPage(System::Windows::Forms::Form^ FormalPage)
		{    
			otherform = FormalPage;
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}
	private: System::Windows::Forms::Button^ BackBut;
	public:

	public:
	private: System::Windows::Forms::Form^ otherform;
	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~RegistrationPage()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Panel^ panel1;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Label^ label7;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::RadioButton^ StudentBut;

	private: System::Windows::Forms::RadioButton^ TeacherBut;

	private: System::Windows::Forms::TextBox^ ComfirmPassText;

	private: System::Windows::Forms::Label^ label8;
	private: System::Windows::Forms::TextBox^ PasswordText;

	private: System::Windows::Forms::TextBox^ IDText;

	private: System::Windows::Forms::TextBox^ SurnameText;

	private: System::Windows::Forms::TextBox^ NameText;
	private: System::Windows::Forms::Button^ RegisterBut;


	private: System::Windows::Forms::Button^ button2;
	private: System::ComponentModel::IContainer^ components;

	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->ComfirmPassText = (gcnew System::Windows::Forms::TextBox());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->PasswordText = (gcnew System::Windows::Forms::TextBox());
			this->IDText = (gcnew System::Windows::Forms::TextBox());
			this->SurnameText = (gcnew System::Windows::Forms::TextBox());
			this->NameText = (gcnew System::Windows::Forms::TextBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->StudentBut = (gcnew System::Windows::Forms::RadioButton());
			this->TeacherBut = (gcnew System::Windows::Forms::RadioButton());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->RegisterBut = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->BackBut = (gcnew System::Windows::Forms::Button());
			this->panel1->SuspendLayout();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Elephant", 21.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(52, 21);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(344, 38);
			this->label1->TabIndex = 1;
			this->label1->Text = L"Registration Template";
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::SystemColors::HotTrack;
			this->panel1->Controls->Add(this->ComfirmPassText);
			this->panel1->Controls->Add(this->label8);
			this->panel1->Controls->Add(this->PasswordText);
			this->panel1->Controls->Add(this->IDText);
			this->panel1->Controls->Add(this->SurnameText);
			this->panel1->Controls->Add(this->NameText);
			this->panel1->Controls->Add(this->label7);
			this->panel1->Controls->Add(this->label6);
			this->panel1->Controls->Add(this->label4);
			this->panel1->Controls->Add(this->label3);
			this->panel1->Controls->Add(this->label2);
			this->panel1->Controls->Add(this->StudentBut);
			this->panel1->Controls->Add(this->TeacherBut);
			this->panel1->Controls->Add(this->label5);
			this->panel1->Location = System::Drawing::Point(59, 62);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(352, 275);
			this->panel1->TabIndex = 2;
			// 
			// ComfirmPassText
			// 
			this->ComfirmPassText->BackColor = System::Drawing::SystemColors::Menu;
			this->ComfirmPassText->Location = System::Drawing::Point(132, 230);
			this->ComfirmPassText->Name = L"ComfirmPassText";
			this->ComfirmPassText->PasswordChar = '*';
			this->ComfirmPassText->Size = System::Drawing::Size(202, 20);
			this->ComfirmPassText->TabIndex = 28;
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label8->Location = System::Drawing::Point(2, 231);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(136, 16);
			this->label8->TabIndex = 27;
			this->label8->Text = L"Confirm Password:";
			// 
			// PasswordText
			// 
			this->PasswordText->BackColor = System::Drawing::SystemColors::Menu;
			this->PasswordText->Location = System::Drawing::Point(95, 199);
			this->PasswordText->Name = L"PasswordText";
			this->PasswordText->PasswordChar = '*';
			this->PasswordText->Size = System::Drawing::Size(239, 20);
			this->PasswordText->TabIndex = 26;
			// 
			// IDText
			// 
			this->IDText->BackColor = System::Drawing::SystemColors::Menu;
			this->IDText->Location = System::Drawing::Point(95, 173);
			this->IDText->Name = L"IDText";
			this->IDText->Size = System::Drawing::Size(239, 20);
			this->IDText->TabIndex = 25;
			// 
			// SurnameText
			// 
			this->SurnameText->BackColor = System::Drawing::SystemColors::Menu;
			this->SurnameText->Location = System::Drawing::Point(95, 147);
			this->SurnameText->Name = L"SurnameText";
			this->SurnameText->Size = System::Drawing::Size(239, 20);
			this->SurnameText->TabIndex = 24;
			// 
			// NameText
			// 
			this->NameText->BackColor = System::Drawing::SystemColors::Menu;
			this->NameText->Location = System::Drawing::Point(95, 121);
			this->NameText->Name = L"NameText";
			this->NameText->Size = System::Drawing::Size(239, 20);
			this->NameText->TabIndex = 23;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label7->Location = System::Drawing::Point(3, 196);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(91, 20);
			this->label7->TabIndex = 22;
			this->label7->Text = L"Password:";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label6->Location = System::Drawing::Point(56, 171);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(33, 20);
			this->label6->TabIndex = 21;
			this->label6->Text = L"ID:";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(3, 151);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(86, 20);
			this->label4->TabIndex = 20;
			this->label4->Text = L"Surname:";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(32, 121);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(57, 18);
			this->label3->TabIndex = 19;
			this->label3->Text = L"Name:";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(3, 91);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(219, 20);
			this->label2->TabIndex = 18;
			this->label2->Text = L"Registeration Information:";
			// 
			// StudentBut
			// 
			this->StudentBut->AutoSize = true;
			this->StudentBut->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->StudentBut->Location = System::Drawing::Point(47, 64);
			this->StudentBut->Name = L"StudentBut";
			this->StudentBut->Size = System::Drawing::Size(84, 24);
			this->StudentBut->TabIndex = 17;
			this->StudentBut->TabStop = true;
			this->StudentBut->Text = L"Student";
			this->StudentBut->UseVisualStyleBackColor = true;
			// 
			// TeacherBut
			// 
			this->TeacherBut->AutoSize = true;
			this->TeacherBut->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->TeacherBut->Location = System::Drawing::Point(47, 34);
			this->TeacherBut->Name = L"TeacherBut";
			this->TeacherBut->Size = System::Drawing::Size(89, 24);
			this->TeacherBut->TabIndex = 16;
			this->TeacherBut->TabStop = true;
			this->TeacherBut->Text = L"Teacher ";
			this->TeacherBut->UseVisualStyleBackColor = true;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(3, 9);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(106, 20);
			this->label5->TabIndex = 15;
			this->label5->Text = L"Register as:";
			// 
			// RegisterBut
			// 
			this->RegisterBut->BackColor = System::Drawing::SystemColors::HotTrack;
			this->RegisterBut->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->RegisterBut->Location = System::Drawing::Point(335, 343);
			this->RegisterBut->Name = L"RegisterBut";
			this->RegisterBut->Size = System::Drawing::Size(76, 32);
			this->RegisterBut->TabIndex = 30;
			this->RegisterBut->Text = L"Register";
			this->RegisterBut->UseVisualStyleBackColor = false;
			this->RegisterBut->Click += gcnew System::EventHandler(this, &RegistrationPage::button1_Click);
			// 
			// button2
			// 
			this->button2->BackColor = System::Drawing::SystemColors::GrayText;
			this->button2->Location = System::Drawing::Point(412, 12);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(36, 23);
			this->button2->TabIndex = 31;
			this->button2->Text = L"X";
			this->button2->UseVisualStyleBackColor = false;
			this->button2->Click += gcnew System::EventHandler(this, &RegistrationPage::button2_Click);
			// 
			// BackBut
			// 
			this->BackBut->BackColor = System::Drawing::SystemColors::HotTrack;
			this->BackBut->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->BackBut->Location = System::Drawing::Point(59, 343);
			this->BackBut->Name = L"BackBut";
			this->BackBut->Size = System::Drawing::Size(76, 32);
			this->BackBut->TabIndex = 32;
			this->BackBut->Text = L"Back";
			this->BackBut->UseVisualStyleBackColor = false;
			this->BackBut->Click += gcnew System::EventHandler(this, &RegistrationPage::BackBut_Click);
			// 
			// RegistrationPage
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::MenuHighlight;
			this->ClientSize = System::Drawing::Size(460, 387);
			this->Controls->Add(this->BackBut);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->RegisterBut);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->label1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::None;
			this->Name = L"RegistrationPage";
			this->Text = L"MyForm3";
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
		
			try {
				String^ firstname = NameText->Text;
				String^ Surname = SurnameText->Text;
				int id = Int32::Parse(IDText->Text);
				String^ Password = PasswordText->Text;
				String^ Username = firstname + Surname;
				
				if (ComfirmPassText->Text != PasswordText->Text) {
					MessageBox::Show("Password does not match", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
				}
				
				else {
					if (TeacherBut->Checked) {
						RegistrationData^ reg = gcnew RegistrationData();
						reg->InsertDataT(id,firstname, Surname,Username, Password);
						MessageBox::Show("Registration successfully, Your login username is: " + Username);
						this->Hide();
						otherform->Show();
					}
					else {

						RegistrationData^ reg = gcnew RegistrationData();
						reg->InsertDataS(id, firstname, Surname, Username, Password);
						MessageBox::Show("Registration successfully, Your login username is: " + Username);
						this->Hide();
						otherform->Show();

					}
				}
			}
			catch (Exception^ ex) {
				MessageBox::Show(ex->Message);
			}
	}
private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {
	if (MessageBox::Show("Do you really want to Exit?", "QuizAPP", MessageBoxButtons::YesNo, MessageBoxIcon::Question) == System::Windows::Forms::DialogResult::Yes) {
		Application::Exit();
	}
	else {
		System::Windows::Forms::DialogResult::Cancel;
	}
}
private: System::Void BackBut_Click(System::Object^ sender, System::EventArgs^ e) {
	this->Hide();
	otherform->Show();
}
};
}
