#pragma once
#include"FormalPage.h"
#include"InformalPage.h"

namespace Project4 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class HomePage : public System::Windows::Forms::Form
	{
	public:
		HomePage(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~HomePage()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Panel^ panel1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::RadioButton^ InformalBut;

	private: System::Windows::Forms::RadioButton^ FormalBut;

	private: System::Windows::Forms::Button^ ExitBut;
	private: System::Windows::Forms::Button^ NextBut;


	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->InformalBut = (gcnew System::Windows::Forms::RadioButton());
			this->FormalBut = (gcnew System::Windows::Forms::RadioButton());
			this->ExitBut = (gcnew System::Windows::Forms::Button());
			this->NextBut = (gcnew System::Windows::Forms::Button());
			this->panel1->SuspendLayout();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Elephant", 48, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(61, 19);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(336, 83);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Quiz App";
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::SystemColors::HotTrack;
			this->panel1->Controls->Add(this->label2);
			this->panel1->Controls->Add(this->InformalBut);
			this->panel1->Controls->Add(this->FormalBut);
			this->panel1->Location = System::Drawing::Point(61, 105);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(366, 194);
			this->panel1->TabIndex = 1;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(3, 20);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(197, 20);
			this->label2->TabIndex = 2;
			this->label2->Text = L"Select the type of Quiz:";
			// 
			// InformalBut
			// 
			this->InformalBut->AutoSize = true;
			this->InformalBut->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->InformalBut->Location = System::Drawing::Point(23, 111);
			this->InformalBut->Name = L"InformalBut";
			this->InformalBut->Size = System::Drawing::Size(121, 24);
			this->InformalBut->TabIndex = 1;
			this->InformalBut->TabStop = true;
			this->InformalBut->Text = L"Informal Quiz";
			this->InformalBut->UseVisualStyleBackColor = true;
			// 
			// FormalBut
			// 
			this->FormalBut->AutoSize = true;
			this->FormalBut->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->FormalBut->Location = System::Drawing::Point(23, 63);
			this->FormalBut->Name = L"FormalBut";
			this->FormalBut->Size = System::Drawing::Size(112, 24);
			this->FormalBut->TabIndex = 0;
			this->FormalBut->TabStop = true;
			this->FormalBut->Text = L"Formal Quiz";
			this->FormalBut->UseVisualStyleBackColor = true;
			// 
			// ExitBut
			// 
			this->ExitBut->BackColor = System::Drawing::SystemColors::HotTrack;
			this->ExitBut->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->ExitBut->Location = System::Drawing::Point(61, 314);
			this->ExitBut->Name = L"ExitBut";
			this->ExitBut->Size = System::Drawing::Size(75, 30);
			this->ExitBut->TabIndex = 2;
			this->ExitBut->Text = L"Exit";
			this->ExitBut->UseVisualStyleBackColor = false;
			this->ExitBut->Click += gcnew System::EventHandler(this, &HomePage::button1_Click);
			// 
			// NextBut
			// 
			this->NextBut->BackColor = System::Drawing::SystemColors::HotTrack;
			this->NextBut->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->NextBut->Location = System::Drawing::Point(342, 314);
			this->NextBut->Name = L"NextBut";
			this->NextBut->Size = System::Drawing::Size(75, 30);
			this->NextBut->TabIndex = 3;
			this->NextBut->Text = L"Next";
			this->NextBut->UseVisualStyleBackColor = false;
			this->NextBut->Click += gcnew System::EventHandler(this, &HomePage::NextBut_Click);
			// 
			// HomePage
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::MenuHighlight;
			this->ClientSize = System::Drawing::Size(460, 373);
			this->Controls->Add(this->NextBut);
			this->Controls->Add(this->ExitBut);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->label1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::None;
			this->Name = L"HomePage";
			this->Text = L"MyForm";
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
		if (MessageBox::Show("Do you really want to Exit?", "QuizAPP", MessageBoxButtons::YesNo, MessageBoxIcon::Question) == System::Windows::Forms::DialogResult::Yes) {
			Application::Exit();
		}
		else {
			System::Windows::Forms::DialogResult::Cancel;
		}
	}

private: System::Void NextBut_Click(System::Object^ sender, System::EventArgs^ e) {
	if (FormalBut->Checked) {
		this->Hide();
		FormalPage^ formal = gcnew FormalPage(this);
		formal->Show();
	}
	else {
		this->Hide();
		InformalPage^ formal = gcnew InformalPage(this);
		formal->Show();
	}
}   
};
}
