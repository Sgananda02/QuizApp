#pragma once
#include "HomePage.h"
#include "GenerateQuiz.h"
#include "Upload.h"
#include "AttemptQuiz.h"
namespace Project4 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm2
	/// </summary>
	public ref class InformalPage : public System::Windows::Forms::Form
	{
	public:
		InformalPage(System::Windows::Forms::Form^ HomePage)
		{
			otherform = HomePage;
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}
	private: System::Windows::Forms::RadioButton^ AttemptBut;
	private: System::Windows::Forms::Form^ otherform;
	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~InformalPage()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	protected:
	private: System::Windows::Forms::Panel^ panel1;
	private: System::Windows::Forms::TextBox^ QuizTitleText;

	private: System::Windows::Forms::TextBox^ QuizIdText;

	private: System::Windows::Forms::TextBox^ UserNameText;

	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::RadioButton^ UploadBut;


	private: System::Windows::Forms::RadioButton^ GenerateBut;

	private: System::Windows::Forms::Button^ BackBut;


	private: System::Windows::Forms::Button^ NextBut;
	private: System::Windows::Forms::Button^ button1;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->UploadBut = (gcnew System::Windows::Forms::RadioButton());
			this->GenerateBut = (gcnew System::Windows::Forms::RadioButton());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->QuizTitleText = (gcnew System::Windows::Forms::TextBox());
			this->QuizIdText = (gcnew System::Windows::Forms::TextBox());
			this->UserNameText = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->BackBut = (gcnew System::Windows::Forms::Button());
			this->NextBut = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->AttemptBut = (gcnew System::Windows::Forms::RadioButton());
			this->panel1->SuspendLayout();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Elephant", 36, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(39, 9);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(370, 62);
			this->label1->TabIndex = 1;
			this->label1->Text = L"Informal Quiz";
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::SystemColors::HotTrack;
			this->panel1->Controls->Add(this->AttemptBut);
			this->panel1->Controls->Add(this->UploadBut);
			this->panel1->Controls->Add(this->GenerateBut);
			this->panel1->Controls->Add(this->label5);
			this->panel1->Controls->Add(this->QuizTitleText);
			this->panel1->Controls->Add(this->QuizIdText);
			this->panel1->Controls->Add(this->UserNameText);
			this->panel1->Controls->Add(this->label3);
			this->panel1->Controls->Add(this->label2);
			this->panel1->Controls->Add(this->label4);
			this->panel1->Location = System::Drawing::Point(57, 74);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(352, 254);
			this->panel1->TabIndex = 2;
			// 
			// UploadBut
			// 
			this->UploadBut->AutoSize = true;
			this->UploadBut->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->UploadBut->Location = System::Drawing::Point(37, 169);
			this->UploadBut->Name = L"UploadBut";
			this->UploadBut->Size = System::Drawing::Size(127, 24);
			this->UploadBut->TabIndex = 16;
			this->UploadBut->TabStop = true;
			this->UploadBut->Text = L"Upload a Quiz";
			this->UploadBut->UseVisualStyleBackColor = true;
			// 
			// GenerateBut
			// 
			this->GenerateBut->AutoSize = true;
			this->GenerateBut->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->GenerateBut->Location = System::Drawing::Point(37, 139);
			this->GenerateBut->Name = L"GenerateBut";
			this->GenerateBut->Size = System::Drawing::Size(131, 24);
			this->GenerateBut->TabIndex = 15;
			this->GenerateBut->TabStop = true;
			this->GenerateBut->Text = L"Generate Quiz";
			this->GenerateBut->UseVisualStyleBackColor = true;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(3, 106);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(151, 20);
			this->label5->TabIndex = 14;
			this->label5->Text = L"Select one below:";
			// 
			// QuizTitleText
			// 
			this->QuizTitleText->BackColor = System::Drawing::SystemColors::Menu;
			this->QuizTitleText->Location = System::Drawing::Point(96, 73);
			this->QuizTitleText->Name = L"QuizTitleText";
			this->QuizTitleText->Size = System::Drawing::Size(239, 20);
			this->QuizTitleText->TabIndex = 13;
			// 
			// QuizIdText
			// 
			this->QuizIdText->BackColor = System::Drawing::SystemColors::Menu;
			this->QuizIdText->Location = System::Drawing::Point(96, 38);
			this->QuizIdText->Name = L"QuizIdText";
			this->QuizIdText->Size = System::Drawing::Size(239, 20);
			this->QuizIdText->TabIndex = 12;
			// 
			// UserNameText
			// 
			this->UserNameText->BackColor = System::Drawing::SystemColors::Menu;
			this->UserNameText->Location = System::Drawing::Point(96, 12);
			this->UserNameText->Name = L"UserNameText";
			this->UserNameText->Size = System::Drawing::Size(239, 20);
			this->UserNameText->TabIndex = 11;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(3, 71);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(89, 20);
			this->label3->TabIndex = 10;
			this->label3->Text = L"Quiz Title:";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(3, 38);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(71, 20);
			this->label2->TabIndex = 9;
			this->label2->Text = L"Quiz Id:";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(3, 10);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(96, 20);
			this->label4->TabIndex = 8;
			this->label4->Text = L"Username:";
			// 
			// BackBut
			// 
			this->BackBut->BackColor = System::Drawing::SystemColors::HotTrack;
			this->BackBut->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->BackBut->Location = System::Drawing::Point(57, 338);
			this->BackBut->Name = L"BackBut";
			this->BackBut->Size = System::Drawing::Size(75, 30);
			this->BackBut->TabIndex = 4;
			this->BackBut->Text = L"Back";
			this->BackBut->UseVisualStyleBackColor = false;
			this->BackBut->Click += gcnew System::EventHandler(this, &InformalPage::BackBut_Click);
			// 
			// NextBut
			// 
			this->NextBut->BackColor = System::Drawing::SystemColors::HotTrack;
			this->NextBut->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->NextBut->Location = System::Drawing::Point(334, 338);
			this->NextBut->Name = L"NextBut";
			this->NextBut->Size = System::Drawing::Size(75, 30);
			this->NextBut->TabIndex = 5;
			this->NextBut->Text = L"Next";
			this->NextBut->UseVisualStyleBackColor = false;
			this->NextBut->Click += gcnew System::EventHandler(this, &InformalPage::NextBut_Click);
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::SystemColors::GrayText;
			this->button1->Location = System::Drawing::Point(412, 9);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(36, 23);
			this->button1->TabIndex = 17;
			this->button1->Text = L"X";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &InformalPage::button1_Click);
			// 
			// AttemptBut
			// 
			this->AttemptBut->AutoSize = true;
			this->AttemptBut->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->AttemptBut->Location = System::Drawing::Point(37, 209);
			this->AttemptBut->Name = L"AttemptBut";
			this->AttemptBut->Size = System::Drawing::Size(120, 24);
			this->AttemptBut->TabIndex = 17;
			this->AttemptBut->TabStop = true;
			this->AttemptBut->Text = L"Attempt Quiz";
			this->AttemptBut->UseVisualStyleBackColor = true;
			// 
			// InformalPage
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::MenuHighlight;
			this->ClientSize = System::Drawing::Size(460, 380);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->NextBut);
			this->Controls->Add(this->BackBut);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->label1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::None;
			this->Name = L"InformalPage";
			this->Text = L"MyForm2";
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void NextBut_Click(System::Object^ sender, System::EventArgs^ e) {
		try {
			String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=quizapp";
			MySqlConnection^ DBconnect = gcnew MySqlConnection(constr);
			int quizid = Int32::Parse(QuizIdText->Text);
			String^ quiztitle = QuizTitleText->Text;
			String^ role = "User";
			String^ username = UserNameText->Text;
			
			if (GenerateBut->Checked || UploadBut->Checked) {
				InformalData^ data = gcnew InformalData();
				data->InsertDataI(quizid, quiztitle, role);
				
				if (GenerateBut->Checked) {
					this->Hide();
					Generate^ Gen = gcnew Generate(this, this);
					Gen->quizID = quizid;
					Gen->quizTitle = quiztitle;
					Gen->Show();
					DBconnect->Close();
				}
				else {
					this->Hide();
					Upload^ upl = gcnew Upload(this, this);
					upl->quizID = quizid;
					upl->quizTitle = quiztitle;
					upl->Show();
					DBconnect->Close();
				}
			}
			else {
			
				InformalData^ d = gcnew InformalData();
				d->GetDataQ(quizid);
				while (d->rdr->Read()) {
					String^ quizTitle = d->rdr->GetString(1);
					String^ Role = d->rdr->GetString(2);

					if (quiztitle == quizTitle && role == Role) {
						this->Hide();
						AttemptQuiz^ att = gcnew AttemptQuiz(this, this);
						att->quizId = quizid;
						att->quizTilte = quiztitle;
						att->Username = username;
						att->Role = role;
						att->Show();
					}
					else {
						MessageBox::Show("Invalid Quiz ", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
					}
				}
				
			}
		}
		catch (Exception^ ex) {
			MessageBox::Show(ex->Message);
		}
		
	}
	private: System::Void BackBut_Click(System::Object^ sender, System::EventArgs^ e) {
		this->Hide();
		otherform->Show();
	}
    private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
	if (MessageBox::Show("Do you really want to Exit?", "Quiz App", MessageBoxButtons::YesNo, MessageBoxIcon::Question) == System::Windows::Forms::DialogResult::Yes) {
		Application::Exit();
	}
	else {
		System::Windows::Forms::DialogResult::Cancel;
	}
}
};
}
