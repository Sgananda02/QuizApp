#pragma once
#include "FormalPage.h"
#include "AttemptQuiz.h"
namespace Project4 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm5
	/// </summary>
	public ref class StudentPage : public System::Windows::Forms::Form
	{
	public:
		static StudentPage^ instance;
		StudentPage(System::Windows::Forms::Form^ FormalPage)
		{
			otherform = FormalPage;
			instance = this;
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}
	private: System::Windows::Forms::Form^ otherform;
	public: String^ username;
	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~StudentPage()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Panel^ panel1;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::TextBox^ QuizTitleText;

	private: System::Windows::Forms::TextBox^ QuizIdText;
	private: System::Windows::Forms::Button^ AttemptBut;
	private: System::Windows::Forms::Button^ BackBut;
	private: System::Windows::Forms::Button^ button1;



	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->AttemptBut = (gcnew System::Windows::Forms::Button());
			this->QuizTitleText = (gcnew System::Windows::Forms::TextBox());
			this->QuizIdText = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->BackBut = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->panel1->SuspendLayout();
			this->SuspendLayout();
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(32, 24);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(117, 20);
			this->label2->TabIndex = 5;
			this->label2->Text = L"Dear Student";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(32, 44);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(206, 20);
			this->label1->TabIndex = 6;
			this->label1->Text = L"welcome to the Quiz app";
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::SystemColors::HotTrack;
			this->panel1->Controls->Add(this->AttemptBut);
			this->panel1->Controls->Add(this->QuizTitleText);
			this->panel1->Controls->Add(this->QuizIdText);
			this->panel1->Controls->Add(this->label4);
			this->panel1->Controls->Add(this->label3);
			this->panel1->Location = System::Drawing::Point(36, 79);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(396, 241);
			this->panel1->TabIndex = 7;
			// 
			// AttemptBut
			// 
			this->AttemptBut->BackColor = System::Drawing::SystemColors::MenuHighlight;
			this->AttemptBut->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->AttemptBut->Location = System::Drawing::Point(141, 132);
			this->AttemptBut->Name = L"AttemptBut";
			this->AttemptBut->Size = System::Drawing::Size(94, 36);
			this->AttemptBut->TabIndex = 18;
			this->AttemptBut->Text = L"Attempt Quiz";
			this->AttemptBut->UseVisualStyleBackColor = false;
			this->AttemptBut->Click += gcnew System::EventHandler(this, &StudentPage::AttemptBut_Click);
			// 
			// QuizTitleText
			// 
			this->QuizTitleText->BackColor = System::Drawing::SystemColors::Menu;
			this->QuizTitleText->Location = System::Drawing::Point(108, 63);
			this->QuizTitleText->Name = L"QuizTitleText";
			this->QuizTitleText->Size = System::Drawing::Size(238, 20);
			this->QuizTitleText->TabIndex = 17;
			// 
			// QuizIdText
			// 
			this->QuizIdText->BackColor = System::Drawing::SystemColors::Menu;
			this->QuizIdText->Location = System::Drawing::Point(108, 33);
			this->QuizIdText->Name = L"QuizIdText";
			this->QuizIdText->Size = System::Drawing::Size(238, 20);
			this->QuizIdText->TabIndex = 16;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(13, 63);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(89, 20);
			this->label4->TabIndex = 15;
			this->label4->Text = L"Quiz Title:";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(22, 33);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(71, 20);
			this->label3->TabIndex = 11;
			this->label3->Text = L"Quiz Id:";
			// 
			// BackBut
			// 
			this->BackBut->BackColor = System::Drawing::SystemColors::HotTrack;
			this->BackBut->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->BackBut->Location = System::Drawing::Point(196, 338);
			this->BackBut->Name = L"BackBut";
			this->BackBut->Size = System::Drawing::Size(75, 30);
			this->BackBut->TabIndex = 8;
			this->BackBut->Text = L"Back";
			this->BackBut->UseVisualStyleBackColor = false;
			this->BackBut->Click += gcnew System::EventHandler(this, &StudentPage::BackBut_Click);
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::SystemColors::GrayText;
			this->button1->Location = System::Drawing::Point(396, 12);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(36, 23);
			this->button1->TabIndex = 17;
			this->button1->Text = L"X";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &StudentPage::button1_Click);
			// 
			// StudentPage
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::MenuHighlight;
			this->ClientSize = System::Drawing::Size(460, 380);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->BackBut);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->label2);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::None;
			this->Name = L"StudentPage";
			this->Text = L"MyForm5";
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void BackBut_Click(System::Object^ sender, System::EventArgs^ e) {
		this->Hide();
		otherform->Show();
	}
private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
	if (MessageBox::Show("Do you really want to Exit?", "QuizAPP", MessageBoxButtons::YesNo, MessageBoxIcon::Question) == System::Windows::Forms::DialogResult::Yes) {
		Application::Exit();
	}
	else {
		System::Windows::Forms::DialogResult::Cancel;
	}
}
private: System::Void AttemptBut_Click(System::Object^ sender, System::EventArgs^ e) {
	try
	{
		String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=quizapp";
		MySqlConnection^ DBconnect = gcnew MySqlConnection(constr);
		int quizid = Int32::Parse(QuizIdText->Text);
		String^ quiztitle = QuizTitleText->Text;
		String^ role = "Teacher";
		MySqlCommand^ cmd = gcnew MySqlCommand("select * from quiz_table where quizId=" + quizid + "", DBconnect);
		DBconnect->Open();
		MySqlDataReader^ reader = cmd->ExecuteReader();
		String^ quizT;
		String^ Role;
		while (reader->Read()) {
			quizT = reader->GetString(1);
			Role = reader->GetString(2);


			if (quiztitle == quizT && role == Role) {

				this->Hide();
				AttemptQuiz^ attempt = gcnew AttemptQuiz(this, this);
				attempt->quizId = quizid;
				attempt->quizTilte = quiztitle;
				attempt->Username=username;
				attempt->Role = role;
				attempt->Show();
			}
		
		else {
		MessageBox::Show("Invalid QuizId or Quiz Title ", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
	}
	}
	catch (Exception^ ex) {
			MessageBox::Show(ex->Message);
	}
	
}
};
}
