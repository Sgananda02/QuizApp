#pragma once

namespace Project4 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;
	/// <summary>
	/// Summary for MyForm1
	/// </summary>
	public ref class Generate: public System::Windows::Forms::Form
	{
	public:
		Generate(System::Windows::Forms::Form^ TeacherPage, System::Windows::Forms::Form^ InformalPage)
		{   
			
			otherform = TeacherPage;
			otherform2 = InformalPage;
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}
		
	public:
		int quizID;
		String^ quizTitle;
		int QuestionNum;
		
	private: System::Windows::Forms::Form^ otherform;
	private: System::Windows::Forms::Form^ otherform2;
	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Generate()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	protected:
	private: System::Windows::Forms::TextBox^ NoQuestionTex;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::TextBox^ QuestionText;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::TextBox^ Answer1Text;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::TextBox^ Answer2Text;
	private: System::Windows::Forms::TextBox^ Answer3Text;
	private: System::Windows::Forms::TextBox^ Answer4Text;
	private: System::Windows::Forms::Label^ label7;
	private: System::Windows::Forms::TextBox^ CorrAnswerText;
	private: System::Windows::Forms::Button^ NextBut;
	private: System::Windows::Forms::Button^ BackBut;
	private: System::Windows::Forms::Button^ button1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->NoQuestionTex = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->QuestionText = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->Answer1Text = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->Answer2Text = (gcnew System::Windows::Forms::TextBox());
			this->Answer3Text = (gcnew System::Windows::Forms::TextBox());
			this->Answer4Text = (gcnew System::Windows::Forms::TextBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->CorrAnswerText = (gcnew System::Windows::Forms::TextBox());
			this->NextBut = (gcnew System::Windows::Forms::Button());
			this->BackBut = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(16, 30);
			this->label1->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(208, 16);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Enter the number of question:";
			// 
			// NoQuestionTex
			// 
			this->NoQuestionTex->BackColor = System::Drawing::SystemColors::Window;
			this->NoQuestionTex->Location = System::Drawing::Point(223, 30);
			this->NoQuestionTex->Name = L"NoQuestionTex";
			this->NoQuestionTex->Size = System::Drawing::Size(73, 22);
			this->NoQuestionTex->TabIndex = 1;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(13, 83);
			this->label2->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(73, 16);
			this->label2->TabIndex = 2;
			this->label2->Text = L"Question:";
			// 
			// QuestionText
			// 
			this->QuestionText->Location = System::Drawing::Point(84, 83);
			this->QuestionText->Multiline = true;
			this->QuestionText->Name = L"QuestionText";
			this->QuestionText->Size = System::Drawing::Size(360, 62);
			this->QuestionText->TabIndex = 3;
			this->QuestionText->Text = L"\r\n\r\n";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(12, 165);
			this->label3->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(74, 16);
			this->label3->TabIndex = 4;
			this->label3->Text = L"Answer 1:";
			// 
			// Answer1Text
			// 
			this->Answer1Text->Location = System::Drawing::Point(84, 162);
			this->Answer1Text->Multiline = true;
			this->Answer1Text->Name = L"Answer1Text";
			this->Answer1Text->Size = System::Drawing::Size(360, 22);
			this->Answer1Text->TabIndex = 5;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(12, 203);
			this->label4->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(74, 16);
			this->label4->TabIndex = 6;
			this->label4->Text = L"Answer 2:";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(12, 242);
			this->label5->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(74, 16);
			this->label5->TabIndex = 7;
			this->label5->Text = L"Answer 3:";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label6->Location = System::Drawing::Point(12, 276);
			this->label6->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(74, 16);
			this->label6->TabIndex = 8;
			this->label6->Text = L"Answer 4:";
			// 
			// Answer2Text
			// 
			this->Answer2Text->Location = System::Drawing::Point(84, 197);
			this->Answer2Text->Multiline = true;
			this->Answer2Text->Name = L"Answer2Text";
			this->Answer2Text->Size = System::Drawing::Size(360, 22);
			this->Answer2Text->TabIndex = 9;
			// 
			// Answer3Text
			// 
			this->Answer3Text->Location = System::Drawing::Point(84, 239);
			this->Answer3Text->Name = L"Answer3Text";
			this->Answer3Text->Size = System::Drawing::Size(360, 22);
			this->Answer3Text->TabIndex = 10;
			// 
			// Answer4Text
			// 
			this->Answer4Text->Location = System::Drawing::Point(84, 273);
			this->Answer4Text->Name = L"Answer4Text";
			this->Answer4Text->Size = System::Drawing::Size(360, 22);
			this->Answer4Text->TabIndex = 11;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label7->Location = System::Drawing::Point(3, 307);
			this->label7->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(120, 16);
			this->label7->TabIndex = 12;
			this->label7->Text = L"Correct Answer :";
			// 
			// CorrAnswerText
			// 
			this->CorrAnswerText->Location = System::Drawing::Point(130, 304);
			this->CorrAnswerText->Name = L"CorrAnswerText";
			this->CorrAnswerText->Size = System::Drawing::Size(314, 22);
			this->CorrAnswerText->TabIndex = 13;
			// 
			// NextBut
			// 
			this->NextBut->BackColor = System::Drawing::SystemColors::HotTrack;
			this->NextBut->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->NextBut->Location = System::Drawing::Point(369, 348);
			this->NextBut->Name = L"NextBut";
			this->NextBut->Size = System::Drawing::Size(75, 30);
			this->NextBut->TabIndex = 14;
			this->NextBut->Text = L"Next";
			this->NextBut->UseVisualStyleBackColor = false;
			this->NextBut->Click += gcnew System::EventHandler(this, &Generate::NextBut_Click);
			// 
			// BackBut
			// 
			this->BackBut->BackColor = System::Drawing::SystemColors::HotTrack;
			this->BackBut->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->BackBut->Location = System::Drawing::Point(84, 348);
			this->BackBut->Name = L"BackBut";
			this->BackBut->Size = System::Drawing::Size(75, 30);
			this->BackBut->TabIndex = 15;
			this->BackBut->Text = L"Back";
			this->BackBut->UseVisualStyleBackColor = false;
			this->BackBut->Click += gcnew System::EventHandler(this, &Generate::BackBut_Click);
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::SystemColors::GrayText;
			this->button1->Location = System::Drawing::Point(412, 12);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(36, 23);
			this->button1->TabIndex = 16;
			this->button1->Text = L"X";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &Generate::button1_Click);
			// 
			// Generate
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::MenuHighlight;
			this->ClientSize = System::Drawing::Size(460, 380);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->BackBut);
			this->Controls->Add(this->NextBut);
			this->Controls->Add(this->CorrAnswerText);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->Answer4Text);
			this->Controls->Add(this->Answer3Text);
			this->Controls->Add(this->Answer2Text);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->Answer1Text);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->QuestionText);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->NoQuestionTex);
			this->Controls->Add(this->label1);
			this->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::None;
			this->Margin = System::Windows::Forms::Padding(4);
			this->Name = L"Generate";
			this->Text = L"GenerateQuiz";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void NextBut_Click(System::Object^ sender, System::EventArgs^ e) {
		
		
		String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=quizapp";
		MySqlConnection^ DBconnect = gcnew MySqlConnection(constr);
		try {
			int i=1;
			QuestionNum = Int32::Parse(NoQuestionTex->Text);
			while(i <= QuestionNum) {
				String^ Question = QuestionText->Text;
				String^ Answer1 = Answer1Text->Text;
				String^ Answer2 = Answer2Text->Text;
				String^ Answer3 = Answer3Text->Text;
				String^ Answer4 = Answer4Text->Text;
				String^ correctAnser = CorrAnswerText->Text;
				
				int question_number = i;
				MySqlCommand^ cmd = gcnew MySqlCommand("insert into question_answer value(" + quizID + ",'" + quizTitle + "','" + Question + "','" + Answer1 + "','" + Answer2 + "','" + Answer3 + "','" + Answer4 + "','" + correctAnser + "'," + question_number + ","+QuestionNum+")", DBconnect);
				MySqlDataReader^ rdr;
				quizID = quizID + 1;
				DBconnect->Open();
				rdr = cmd->ExecuteReader();
				QuestionText->Text=" ";
				Answer1Text->Text=" ";
				Answer2Text->Text=" ";
				Answer3Text->Text=" ";
				Answer4Text->Text=" ";
				CorrAnswerText->Text=" ";
				DBconnect->Close();
				i++;
			}
			
			MessageBox::Show("Question stored successfully!!");
			this->Hide();
			otherform->Show();
		}
		catch (Exception^ ex) {
			MessageBox::Show(ex->Message);
		}
	}
private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
	if (MessageBox::Show("Do you really want to Exit?", "QuizAPP", MessageBoxButtons::YesNo, MessageBoxIcon::Question) == System::Windows::Forms::DialogResult::Yes) {
		Application::Exit();
	}
	else {
		System::Windows::Forms::DialogResult::Cancel;
	}
}
private: System::Void BackBut_Click(System::Object^ sender, System::EventArgs^ e) {
	this->Hide();
	otherform->Show();
}
};
}
